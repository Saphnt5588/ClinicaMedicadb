CREATE VIEW View_Consulta_Receta_Medicamento AS 
SELECT
    c.IdConsulta,
    c.FechaConsulta,
    r.IdReceta,
    m.Medicamento AS NombreMedicamento,
    m.Indicaciones,
    r.Dosis
FROM Recetas r
JOIN Consultas c ON r.IdConsulta = c.IdConsulta
JOIN Recetas m ON r.IdReceta = m.IdReceta;